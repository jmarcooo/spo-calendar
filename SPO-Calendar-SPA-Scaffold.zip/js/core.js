// Shared Firebase config & state
